package controller;

import java.util.List;

import dao.ChamadoDao;
import dao.VeiculoDao;
import model.Chamado;
import model.Veiculo;

public class VeiculoController {

  public void registrarVeiculo(Veiculo veiculo) throws Exception {
    if (veiculo.getModelo() == null) {
      throw new Exception("Modelo inv�lido");
    }
    VeiculoDao.getInstance().registrarVeiculo(veiculo);
  }
  
  public List<Veiculo> listar() {
	    return VeiculoDao.getInstance().listar();
	  }
}