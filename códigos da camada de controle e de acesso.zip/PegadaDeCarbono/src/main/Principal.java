package main;

import controller.ChamadoController;
import controller.ColaboradoresController;
import controller.VeiculoController;
import model.Colaboradores;
import model.Chamado;
import model.Veiculo;

public class Principal {
	public static void main(String[] args) { 
		Colaboradores colaborador1 = new Colaboradores(1, 123456789, "Jorge", 20020810, true);

		Colaboradores colaborador2 = new Colaboradores(2, 987654321, "Mario", 20030321, false);
		
		ColaboradoresController controller = new ColaboradoresController();
		
		try {
		controller.salvar(colaborador1);
		controller.salvar(colaborador2);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		for (Colaboradores c : controller.listar()) {
			System.out.println(c.toString());
		}
		
		Veiculo carro1 = new Veiculo("ABC-1234", "Celta", "Preto", 2021, 14);
		
		Veiculo carro2 = new Veiculo("DEF-2846", "Fiesta", "Azul", 2018, 14);
		
		VeiculoController carroController = new VeiculoController();
		
		try {
			carroController.registrarVeiculo(carro1);
			carroController.registrarVeiculo(carro2);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			for (Veiculo c : carroController.listar()) {
				System.out.println(c.toString());
			}
			
		Chamado chamado1 = new Chamado(1, 54);
		
		Chamado chamado2 = new Chamado(2, 102);
		
		ChamadoController chamadocontroller = new ChamadoController();
		
		try {
			chamadocontroller.salvar(chamado1);
			chamadocontroller.salvar(chamado2);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			for (Chamado c : chamadocontroller.listar()) {
				System.out.println(c.toString());
			}
}
}
